from flask import Flask,render_template,Response,request,flash
import sqlite3
import cv2

app=Flask(__name__)
app.config['SECRET_KEY'] = "This is my super key"

def generate_frames():
    camera=cv2.VideoCapture(0)
    while True:
        while True:
            success,frame=camera.read()
            if not success:
                break
            else:
                gray_img = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
                face_cascade = cv2.CascadeClassifier("Haarcascades/haarcascade_frontalface_default.xml")
                face = face_cascade.detectMultiScale(gray_img,1.1,4)
                for (x,y,w,h) in face:
                    cv2.rectangle(frame,(x,y),(x+w,y+h),(255,0,0),2)
                                            
                ret,buffer=cv2.imencode('.jpg',frame)
                frame=buffer.tobytes()
                yield(b'--frame\r\n'
                            b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')



@app.route('/', methods=['POST','GET'])
def login():
    if request.method=='POST':
        result = request.form
        conn = sqlite3.connect("student.db")
        c = conn.cursor()
        det = []
        c.execute("SELECT * FROM STUDENT_DETAILS WHERE roll=?",[result['roll']])
        det = c.fetchall()
        if len(det)!=0:
            if det[0][4]==result['pwd']:
                flash("Successful Login")
                return render_template('index.html', user = det[0])
            else :
                flash("Wrong Password")
        else :
            flash("User Does not exit")
    return render_template('login.html')

@app.route('/video')
def video():
    return Response(generate_frames(),mimetype='multipart/x-mixed-replace; boundary=frame')

# Invalid URL
@app.errorhandler(404)
def page_not_found(e):
    return render_template("404.html"), 404

# Internal Server Error
@app.errorhandler(500)
def page_not_found(e):
    return render_template("500.html"), 500


if __name__=="__main__":
    app.run(debug=True)

